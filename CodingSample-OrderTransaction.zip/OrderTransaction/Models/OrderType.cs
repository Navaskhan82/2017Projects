﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OrderTransaction.Models
{
    public class OrderType
    {
        /// <summary>
        /// Gets or sets the order type Id
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the order type Name
        /// </summary>
        public string Name { get; set; }
    }
}